import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.styl']
})
export class AboutComponent implements OnInit {
  nombre = "";
  bandera = false;
  informacion = [
    {
      "nombre" : "Lago",
      "info" : "Una de las características que más se disfrutan en el entorno del lago de Sanabria es la variedad cromática del paisaje a lo largo del ciclo estacional, donde se suceden como en pocos lugares tonos cromáticos y contraluces que refunden en perfecta armonía la vegetación y el sustrato rocoso de herencia glaciar. En la base del mismo siempre las aguas del lago, a días bravas y rizadas a días quietas, configurando un espejo en el que se refleja el paisaje. Estos atractivos atraparon en la década de los años 30’s del siglo XX a D. Miguel de Unamuno en su visita al balneario de Bouzas que dejó inmortalizados para siempre en su obra “San Manuel Bueno, mártir” a través de la simbología de la montaña y el lago."
    },
    {
      "nombre" : "Bosque",
      "info" : "Las imagenes de bosques representan  ecosistemas ricos en una vegetación protagonizada principalmente por arboles y diversidad de plantas, mayormente altas. Los bosques recubren una gran cantidad de territorio en todo el globo terráqueo, siendo el hábitat de muchos animales e insectos, además de poseer diversas fuentes hidrológicas en su interior, conservar el suelo y ser de gran importancia para la biosfera, ya que consumen dióxido de carbono."
    },
    {
      "nombre" : "Montaña",
      "info" : "El perfil de las montañas Odle, en Italia, forman uno de los parajes más desafiantes que podemos encontrar en las Dolomitas. Escarpadas, con tremendos acantilados y unas paredes de vértigo, este conjunto montañoso parece haber sido moldeado por las manos de un gigante. Es una verdadera maravilla. Las laderas de la montaña tienen una inclinación de los más pronunciada. Cuidado, sus caminos pueden llevarte al borde del acantilado."
    }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
