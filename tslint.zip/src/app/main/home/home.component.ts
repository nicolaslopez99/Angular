import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.styl']
})
export class HomeComponent implements OnInit {
  paisajes = [
    {
      "nombre" : "Lago",
      "img" : "https://www.viajejet.com/wp-content/viajes/Lago-Moraine-Parque-Nacional-Banff-Alberta-Canada-1440x810.jpg"
    },
    {
      "nombre": "Bosque",
      "img" : "https://i.ytimg.com/vi/1Z_gKmw7-_o/maxresdefault.jpg"
    },
    {
      "nombre" : "Montaña",
      "img" : "https://aws.traveler.es/prod/designs/v1/assets/1000x667/21251.jpg"
    }
  ];
  bandera = false;

  constructor() { }

  ngOnInit(): void {
  }

}
